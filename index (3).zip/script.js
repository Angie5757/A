// Mostrar la sección seleccionada
function showSection(sectionId) {
    const sections = document.querySelectorAll('main section');
    sections.forEach((section) => {
        section.classList.remove('active');
    });
    document.getElementById(sectionId).classList.add('active');
}

// Cargar datos almacenados en localStorage
let medicalHistoryData = JSON.parse(localStorage.getItem('medicalHistoryData')) || [];
let mentalHealthHistory = JSON.parse(localStorage.getItem('mentalHealthHistory')) || [];

// Guardar archivos en la lista y permitir abrirlos
function saveFile(fileInputId, listId) {
    const fileInput = document.getElementById(fileInputId);
    const fileList = document.getElementById(listId);

    if (fileInput.files.length > 0) {
        const file = fileInput.files[0];
        const listItem = document.createElement('li');
        const fileURL = URL.createObjectURL(file);

        // Crear enlace para abrir el archivo
        const link = document.createElement('a');
        link.href = fileURL;
        link.download = file.name; // Forzar descarga
        link.textContent = file.name;
        link.target = '_blank';

        // Botón para eliminar archivo
        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Eliminar';
        deleteButton.onclick = () => listItem.remove();

        listItem.appendChild(link);
        listItem.appendChild(deleteButton);
        fileList.appendChild(listItem);

        // Limpia el input de archivos
        fileInput.value = '';
    } else {
        alert('Por favor, selecciona un archivo primero.');
    }
}

// Función para guardar el registro médico
function addRecord() {
    const newRecord = {
        temperature: document.getElementById('temperature').value,
        heartRate: document.getElementById('heartRate').value,
        bloodPressure: document.getElementById('bloodPressure').value,
        weight: document.getElementById('weight').value,
        height: document.getElementById('height').value,
        symptoms: document.getElementById('symptoms').value,
        notes: document.getElementById('notes').value
    };

    // Validación
    if (Object.values(newRecord).some(value => value.trim() !== '')) {
        medicalHistoryData.push(newRecord);
        localStorage.setItem('medicalHistoryData', JSON.stringify(medicalHistoryData));
        renderHistory();

        // Limpiar campos
        Object.keys(newRecord).forEach(id => document.getElementById(id).value = '');
    } else {
        alert('Por favor, completa al menos un campo antes de guardar.');
    }
}

// Función para renderizar el historial
function renderHistory() {
    const historyList = document.getElementById('medicalHistory');
    historyList.innerHTML = '';

    medicalHistoryData.forEach((record, index) => {
        const li = document.createElement('li');
        li.innerHTML = `
            <strong>Registro ${index + 1}</strong><br>
            Temperatura: ${record.temperature}°C<br>
            Frecuencia Cardíaca: ${record.heartRate} lpm<br>
            Tensión Arterial: ${record.bloodPressure} mmHg<br>
            Peso: ${record.weight} kg<br>
            Talla: ${record.height} cm<br>
            Síntomas: ${record.symptoms}<br>
            Notas: ${record.notes}<br>
            <button onclick="deleteRecord(${index})">Eliminar</button>
        `;
        historyList.appendChild(li);
    });
}

// Función para eliminar un registro
function deleteRecord(index) {
    medicalHistoryData.splice(index, 1);
    localStorage.setItem('medicalHistoryData', JSON.stringify(medicalHistoryData));
    renderHistory();
}

// Guardar crisis de salud mental
function saveCrisis() {
    saveMentalHealthRecord('crisis-date', 'crisis-description', 'crisis');
}

// Guardar progreso de salud mental
function saveProgress() {
    saveMentalHealthRecord('progress-date', 'progress-description', 'progress');
}

// Función genérica para guardar crisis o progreso
function saveMentalHealthRecord(dateId, descId, type) {
    const date = document.getElementById(dateId).value;
    const description = document.getElementById(descId).value;

    if (date && description) {
        const record = { type, date, description };
        mentalHealthHistory.push(record);
        localStorage.setItem('mentalHealthHistory', JSON.stringify(mentalHealthHistory));
        updateMentalHealthHistory();

        document.getElementById(dateId).value = '';
        document.getElementById(descId).value = '';
    } else {
        alert('Por favor, completa ambos campos antes de guardar.');
    }
}

// Función para actualizar historial de salud mental
function updateMentalHealthHistory() {
    const listElement = document.getElementById('mental-health-list');
    listElement.innerHTML = '';

    mentalHealthHistory.forEach((record, index) => {
        const listItem = document.createElement('li');
        listItem.classList.add(record.type);
        listItem.innerHTML = `Fecha: ${record.date}, Descripción: ${record.description}, Tipo: ${record.type === 'crisis' ? 'Crisis' : 'Progreso'}`;

        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Eliminar';
        deleteButton.onclick = () => deleteMentalHealthRecord(index);

        listItem.appendChild(deleteButton);
        listElement.appendChild(listItem);
    });

    applyColors();
}

// Función para eliminar un registro de salud mental
function deleteMentalHealthRecord(index) {
    mentalHealthHistory.splice(index, 1);
    localStorage.setItem('mentalHealthHistory', JSON.stringify(mentalHealthHistory));
    updateMentalHealthHistory();
}

// Aplicar colores para diferenciar crisis y progreso
function applyColors() {
    document.querySelectorAll('#mental-health-list li').forEach(item => {
        item.style.backgroundColor = item.classList.contains('crisis') ? 'violet' : 'skyblue';
        item.style.color = 'black';
    });
}

// Alternar visualización de listas
function toggleList(listId, buttonId, showText, hideText) {
    const list = document.getElementById(listId);
    const button = document.getElementById(buttonId);

    if (list.style.display === 'none' || list.style.display === '') {
        list.style.display = 'block';
        button.textContent = hideText;
    } else {
        list.style.display = 'none';
        button.textContent = showText;
    }
}

// Inicializar datos al cargar la página
document.addEventListener('DOMContentLoaded', () => {
    renderHistory();
    updateMentalHealthHistory();
  
});
// Cargar recordatorios almacenados al iniciar
document.addEventListener('DOMContentLoaded', () => {
    reminders = JSON.parse(localStorage.getItem('reminders')) || [];
    renderReminders();
});

// Arreglo para almacenar los recordatorios
let reminders = JSON.parse(localStorage.getItem('reminders')) || [];

// Función para agregar un recordatorio
function addReminder() {
    const reminderDate = document.getElementById('reminder-date').value;
    const reminderText = document.getElementById('reminder-text').value;
    const reminderList = document.getElementById('reminder-list');

    if (reminderDate && reminderText) {
        const reminder = { date: reminderDate, text: reminderText };
        reminders.push(reminder);
        localStorage.setItem('reminders', JSON.stringify(reminders));
        renderReminders();

        // Limpiar campos
        document.getElementById('reminder-date').value = '';
        document.getElementById('reminder-text').value = '';
    } else {
        alert('Por favor, ingresa la fecha y el texto del recordatorio.');
    }
}

// Función para mostrar los recordatorios en la lista
function renderReminders() {
    const reminderList = document.getElementById('reminder-list');
    reminderList.innerHTML = '';

    reminders.forEach((reminder, index) => {
        const li = document.createElement('li');
        li.innerHTML = `📅 <strong>${reminder.date}</strong>: ${reminder.text} 
            <button onclick="deleteReminder(${index})">Eliminar</button>`;
        reminderList.appendChild(li);
    });
}

// Función para eliminar un recordatorio
function deleteReminder(index) {
    reminders.splice(index, 1);
    localStorage.setItem('reminders', JSON.stringify(reminders));
    renderReminders();
}
